@echo off
setlocal EnableExtensions
set "SRC=%~dp0"
set "LIST="
echo ==============================================
echo  Solving Clashes - installer (Revit 2020-2027)
echo ==============================================
echo.
tasklist /FI "IMAGENAME eq Revit.exe" 2>nul | find /I "Revit.exe" >nul
if not errorlevel 1 (
  echo Revit is running. Close Revit completely, then run this file again.
  pause
  exit /b 1
)
echo Looking for Revit on this PC...
for %%Y in (2020 2021 2022 2023 2024 2025 2026 2027) do call :check %%Y
if "%LIST%"=="" (
  echo.
  echo No supported Revit version with a matching build was found.
  pause
  exit /b 1
)
echo.
echo Files will be installed for the CURRENT user only, for:%LIST%
set /p ANSWER=Install now? [y/N]: 
if /I not "%ANSWER%"=="y" exit /b 0
echo.
for %%Y in (%LIST%) do call :install %%Y
echo.
echo Done. Start Revit: tab "MEP Tools" ^> "Solving Clashes".
echo If Revit shows a security window, choose "Always Load".
pause
exit /b 0

:check
set "REV="
if exist "%ProgramFiles%\Autodesk\Revit %1\Revit.exe" set "REV=1"
if exist "%APPDATA%\Autodesk\Revit\Addins\%1" set "REV=1"
if defined REV if exist "%SRC%dll\%1\MEP_Bypass_Tool.dll" (
  echo   found: Revit %1
  set "LIST=%LIST% %1"
)
exit /b 0

:install
set "ADDINS=%APPDATA%\Autodesk\Revit\Addins\%1"
set "DLLDIR=%ADDINS%\MEP_Bypass_Tool"
if not exist "%ADDINS%" mkdir "%ADDINS%"
if exist "%ADDINS%\MEP_Bypass_Tool.addin" copy /Y "%ADDINS%\MEP_Bypass_Tool.addin" "%ADDINS%\MEP_Bypass_Tool.addin.bak" >nul
if not exist "%DLLDIR%" mkdir "%DLLDIR%"
copy /Y "%SRC%dll\%1\MEP_Bypass_Tool.dll" "%DLLDIR%\MEP_Bypass_Tool.dll" >nul
if errorlevel 1 (
  echo   Revit %1: ERROR - could not copy the DLL
  exit /b 1
)
rem Files copied from another PC (zip, USB, e-mail) may be "blocked" by Windows: unblock it.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Unblock-File -LiteralPath '%DLLDIR%\MEP_Bypass_Tool.dll'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "(Get-Content -Raw -LiteralPath '%SRC%MEP_Bypass_Tool.addin.template') -replace '__DLL_PATH__', '%DLLDIR%\MEP_Bypass_Tool.dll' | Set-Content -Encoding UTF8 -LiteralPath '%ADDINS%\MEP_Bypass_Tool.addin'"
if errorlevel 1 (
  echo   Revit %1: ERROR - could not write the .addin manifest
  exit /b 1
)
echo   Revit %1: installed
exit /b 0
