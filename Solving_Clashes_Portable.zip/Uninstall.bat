@echo off
setlocal EnableExtensions
set "LIST="
tasklist /FI "IMAGENAME eq Revit.exe" 2>nul | find /I "Revit.exe" >nul
if not errorlevel 1 (
  echo Revit is running. Close Revit completely, then run this file again.
  pause
  exit /b 1
)
for %%Y in (2020 2021 2022 2023 2024 2025 2026 2027) do call :check %%Y
if "%LIST%"=="" (
  echo Nothing to remove.
  pause
  exit /b 0
)
echo This removes only the Solving Clashes files, for Revit:%LIST%
set /p ANSWER=Remove now? [y/N]: 
if /I not "%ANSWER%"=="y" exit /b 0
for %%Y in (%LIST%) do call :remove %%Y
echo Removed.
pause
exit /b 0

:check
if exist "%APPDATA%\Autodesk\Revit\Addins\%1\MEP_Bypass_Tool.addin" set "LIST=%LIST% %1"
exit /b 0

:remove
set "ADDINS=%APPDATA%\Autodesk\Revit\Addins\%1"
if exist "%ADDINS%\MEP_Bypass_Tool.addin" del /Q "%ADDINS%\MEP_Bypass_Tool.addin"
if exist "%ADDINS%\MEP_Bypass_Tool" rmdir /S /Q "%ADDINS%\MEP_Bypass_Tool"
exit /b 0
