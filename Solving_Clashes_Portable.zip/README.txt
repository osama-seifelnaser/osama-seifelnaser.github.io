Solving Clashes
Included builds for Revit: 2020, 2021, 2022, 2023, 2024, 2025, 2026, 2027
1) Close Revit.  2) Double-click Install.bat and answer y.
   It installs the matching build for every supported Revit found on this PC.
3) Open Revit: tab "MEP Tools" > "Solving Clashes".
Remove with Uninstall.bat.
