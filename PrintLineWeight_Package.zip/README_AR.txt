﻿Print & Line Weights - Seif-Elnaser Group
=========================================

التثبيت (من غير برمجة):
1) فك الضغط عن الملف في أي فولدر على جهازك.
2) قفل Revit لو مفتوح.
3) دوس دبل كليك على install.bat (بيكتشف إصدارات Revit الموجودة ويثبت لكل واحد).
   لو ما اكتشفش حاجة: افتح CMD واكتب  install.bat 2024  (استبدل السنة بسنة Revit عندك).
4) افتح Revit. لو سألك عن الـ Add-in اختار Always Load.
5) هتلاقي تاب MEP Tools > بانل Printing > Print & Line Weights.

الحذف: uninstall.bat

ملاحظات:
- Revit 2022 وما فوق: تصدير PDF كامل (مقاس، اتجاه، ألوان، Combine...).
- Revit 2020 و 2021: بيطبع على Microsoft Print to PDF بإعدادات الطباعة الحالية في Revit، ومفيهش Combine (تجريبي).
- الإضافة غير موقّعة رقمياً، فهيجي رسالة تحذير من Revit أول مرة وهذا طبيعي.
- الإعدادات والـ Profiles في %AppData%\PrintLineWeight
