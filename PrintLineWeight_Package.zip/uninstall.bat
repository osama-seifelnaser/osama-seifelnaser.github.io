@echo off
for %%Y in (2020 2021 2022 2023 2024 2025 2026 2027) do (
  if exist "%AppData%\Autodesk\Revit\Addins\%%Y\PrintLineWeight.addin" del /Q "%AppData%\Autodesk\Revit\Addins\%%Y\PrintLineWeight.addin"
  if exist "%AppData%\Autodesk\Revit\Addins\%%Y\PrintLineWeight" rmdir /S /Q "%AppData%\Autodesk\Revit\Addins\%%Y\PrintLineWeight"
)
echo Removed from all Revit versions. Close Revit and start it again.
pause
