@echo off
setlocal
set "HERE=%~dp0"
set "FOUND=0"

echo.
echo === Print and Line Weights - install ===

rem Usage: install.bat            (auto-detect installed Revit versions)
rem        install.bat 2024       (force a specific version)
if not "%~1"=="" goto :manual

for %%Y in (2020 2021 2022 2023 2024 2025 2026 2027) do (
  if exist "%ProgramFiles%\Autodesk\Revit %%Y\Revit.exe" (call :install %%Y)
)
goto :finish

:manual
call :install %~1
goto :finish

:install
set "Y=%~1"
if not exist "%HERE%%Y%\PrintLineWeight.dll" goto :nobuild
set "ADDINS=%AppData%\Autodesk\Revit\Addins\%Y%"
set "DEST=%ADDINS%\PrintLineWeight"
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%HERE%%Y%\PrintLineWeight.dll" "%DEST%\" >nul
copy /Y "%HERE%PrintLineWeight.addin" "%ADDINS%\" >nul
powershell -NoProfile -Command "Get-ChildItem -LiteralPath '%DEST%' | Unblock-File" >nul 2>&1
powershell -NoProfile -Command "Unblock-File -LiteralPath '%ADDINS%\PrintLineWeight.addin'" >nul 2>&1
echo [OK] Installed for Revit %Y%
set /a FOUND+=1
exit /b 0
:nobuild
echo [skip] No build for Revit %Y% in this package
exit /b 0

:finish
echo.
if "%FOUND%"=="0" echo [!] No supported Revit found. Try: install.bat 2024  (use your Revit year)
if not "%FOUND%"=="0" echo Done. Close Revit if open, then start it again.
if not "%FOUND%"=="0" echo In Revit: tab "MEP Tools" - panel "Printing" - "Print and Line Weights".
if not "%FOUND%"=="0" echo If Revit asks about the add-in, choose "Always Load".
echo.
pause
